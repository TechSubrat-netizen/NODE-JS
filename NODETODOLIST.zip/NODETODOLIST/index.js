const http=require('http');
const fs=require('fs')
const app=http.createServer((req,res)=>{
    if(req.method=='GET' && req. url=='/'){
        let data=fs.readFileSync('./Pages/index.html')
        res.end(data)
    }
    else if(req.method=='POST' && req.url=='/taskData'){
        req.on('data',(data)=>{
           let {task}=JSON.parse(data)
           console.log(task);
           const todoTask=JSON.parse(fs.readFileSync('./JSON/todo.json','utf-8'))
           todoTask.push({
            task,
            id:Math.trunc(Math.random()*10000)
           })
           fs.writeFileSync('./JSON/todo.json',JSON.parse(todoTask))
           res.setHeader(200)

        
           res.end(JSON.stringify({message:"DataRecieved"}))
           
        })
    }
   
})
app.listen("4000","localhost",()=>{
    console.log("server started at http://localhost:4000");
    
})